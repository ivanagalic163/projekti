from turtle import position
from flask import Flask, request
from flask import render_template
from db_data import conn

app = Flask(__name__)

@app.route("/")
def login():
    return render_template('potpis.html')

app.run(debug=True)
