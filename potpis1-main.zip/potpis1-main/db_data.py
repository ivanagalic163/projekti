import psycopg2

conn = psycopg2.connect(
        host="localhost",
        database="ems",
        user='postgres',
        password='emerus2705')